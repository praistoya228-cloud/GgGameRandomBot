import os
import asyncio
import random
import urllib.parse
from aiogram import Bot, Dispatcher, F, types
from aiogram.filters import CommandStart, Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import (
    InlineKeyboardButton, 
    InlineKeyboardMarkup, 
    KeyboardButton, 
    ReplyKeyboardMarkup,
    URLInputFile
)
from g4f.client import Client

TOKEN = os.environ.get("BOT_TOKEN", "8955658216:AAE6eq8n0J9zjC1VcT2NS3lf5WEDXGvM80I")

bot = Bot(token=TOKEN)
dp = Dispatcher(storage=MemoryStorage())
g4f_client = Client()

ACTIVE_GAMES = {}
SAVED_GAMES = {}  
USER_AI_PERSONALITY = {}

GAME_NAMES = {
    "dice": "🎲 Кости", 
    "darts": "🎯 Дартс", 
    "basketball": "🏀 Баскетбол", 
    "bowling": "🎳 Боулинг"
}

class Form(StatesGroup):
    text_editor = State()
    draw_photo = State()
    draw_portrait = State()
    randomizer_choice = State()

def get_reply_keyboard():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="🎮 Игры с Ботом (1 на 1)"), KeyboardButton(text="👥 Игры от 1 до 10 челов")],
            [KeyboardButton(text="📝 Редактор текста"), KeyboardButton(text="🖼️ Создать фото")],
            [KeyboardButton(text="🎲 Рандомайзер"), KeyboardButton(text="🎭 Сменить характер ИИ")],
            [KeyboardButton(text="👤 Профиль"), KeyboardButton(text="🎨 Нарисовать вас")],
            [KeyboardButton(text="📂 Сохранения (/load)")]
        ],
        resize_keyboard=True
    )

def get_inline_keyboard():
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🎮 Игры 1 на 1", callback_data="btn_bot_games"), InlineKeyboardButton(text="👥 Игры до 10 челов", callback_data="btn_multi_games")],
            [InlineKeyboardButton(text="📝 Редактор текста", callback_data="btn_text_edit"), InlineKeyboardButton(text="🖼️ Создать фото", callback_data="btn_create_photo")],
            [InlineKeyboardButton(text="🎲 Рандомайзер", callback_data="btn_randomizer"), InlineKeyboardButton(text="🎭 Характер ИИ", callback_data="btn_ai_personality")],
            [InlineKeyboardButton(text="🎨 Нарисовать вас", callback_data="btn_draw_me"), InlineKeyboardButton(text="📂 Сохранения (/load)", callback_data="cmd_load_inline")]
        ]
    )

def get_bot_games_keyboard():
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🎲 Кости", callback_data="select_game_dice"), InlineKeyboardButton(text="🎯 Дартс", callback_data="select_game_darts")],
            [InlineKeyboardButton(text="🏀 Баскетбол", callback_data="select_game_basketball"), InlineKeyboardButton(text="🎳 Боулинг", callback_data="select_game_bowling")],
            [InlineKeyboardButton(text="⬅ Назад в меню", callback_data="btn_menu")]
        ]
    )

def get_target_points_keyboard(game_code: str):
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="До 3 очков", callback_data=f"start_{game_code}_3"), InlineKeyboardButton(text="До 5 очков", callback_data=f"start_{game_code}_5")],
            [InlineKeyboardButton(text="До 10 очков", callback_data=f"start_{game_code}_10"), InlineKeyboardButton(text="До 15 очков", callback_data=f"start_{game_code}_15")],
            [InlineKeyboardButton(text="⬅️ К выбору игры", callback_data="btn_bot_games")]
        ]
    )

def get_game_action_keyboard(game_code: str):
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🎲 Сделать следующий бросок", callback_data=f"roll_{game_code}")],
            [InlineKeyboardButton(text="💾 Сохранить (/save)", callback_data="cmd_save_inline"), InlineKeyboardButton(text="🛑 Пауза/Стоп (/stop)", callback_data="cmd_stop_inline")]
        ]
    )

def get_saved_games_keyboard(user_id: int):
    user_saves = SAVED_GAMES.get(user_id, {})
    buttons = []
    for game_code, gdata in user_saves.items():
        g_name = GAME_NAMES.get(game_code, game_code)
        btn_text = f"{g_name} ({gdata['user_score']}:{gdata['bot_score']} | цель: {gdata['target']})"
        buttons.append([InlineKeyboardButton(text=btn_text, callback_data=f"load_game_{game_code}")])
    buttons.append([InlineKeyboardButton(text="⬅️ Назад в меню", callback_data="btn_menu")])
    return InlineKeyboardMarkup(inline_keyboard=buttons)

@dp.message(F.text == "👥 Игры от 1 до 10 челов")
@dp.callback_query(F.data == "btn_multi_games")
async def multi_games_menu(event):
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🎲 Бросить кость (1-10)", callback_data="multi_roll_dice")],
        [InlineKeyboardButton(text="🎯 Дартс турнир (1-10)", callback_data="multi_roll_darts")],
        [InlineKeyboardButton(text="⬅ Назад", callback_data="btn_menu")]
    ])
    txt = "👥 **Режим для компании (1-10 человек)**\n\nКидайте по очереди!"
    if isinstance(event, types.CallbackQuery):
        await event.message.edit_text(txt, parse_mode="Markdown", reply_markup=kb)
        await event.answer()
    else:
        await event.answer(txt, parse_mode="Markdown", reply_markup=kb)

@dp.callback_query(F.data.startswith("multi_roll_"))
async def process_multi_roll(callback: types.CallbackQuery):
    g_type = callback.data.replace("multi_roll_", "")
    emoji = "🎲" if g_type == "dice" else "🎯"
    await callback.answer("Бросок!")
    await callback.message.answer("🎲 **Бросает Игрок:**")
    await bot.send_dice(chat_id=callback.message.chat.id, emoji=emoji)

@dp.message(F.text == "📝 Редактор текста")
@dp.callback_query(F.data == "btn_text_edit")
async def text_edit_start(event, state: FSMContext):
    await state.set_state(Form.text_editor)
    msg = "📝 **Редактор текста (ИИ)**\n\nПришлите текст для обработки:"
    if isinstance(event, types.CallbackQuery):
        await event.message.edit_text(msg, parse_mode="Markdown")
        await event.answer()
    else:
        await event.answer(msg, parse_mode="Markdown")

@dp.message(Form.text_editor)
async def process_text_editor(message: types.Message, state: FSMContext):
    await state.clear()
    await message.answer("🔄 **Обрабатываю текст...**")
    try:
        prompt = f"Перепиши красиво:\n\n{message.text}"
        response = await asyncio.to_thread(g4f_client.chat.completions.create, model="gpt-4o-mini", messages=[{"role": "user", "content": prompt}])
        await message.answer(f"✨ **Результат:**\n\n{response.choices[0].message.content}", reply_markup=get_reply_keyboard())
    except Exception:
        await message.answer("❌ Ошибка обработки текста.")

@dp.message(F.text == "🖼️ Создать фото")
@dp.callback_query(F.data == "btn_create_photo")
async def create_photo_start(event, state: FSMContext):
    await state.set_state(Form.draw_photo)
    msg = "🖼️ **Генератор картинок**\n\nНапишите описание картинки:"
    if isinstance(event, types.CallbackQuery):
        await event.message.edit_text(msg, parse_mode="Markdown")
        await event.answer()
    else:
        await event.answer(msg, parse_mode="Markdown")

@dp.message(Form.draw_photo)
async def process_photo_generation(message: types.Message, state: FSMContext):
    await state.clear()
    await message.answer("🎨 **Генерирую...**")
    try:
        encoded_prompt = urllib.parse.quote(message.text)
        img_url = f"https://image.pollinations.ai/prompt/{encoded_prompt}?width=800&height=800&nologo=true"
        await message.answer_photo(photo=URLInputFile(img_url), caption=f"🖼️ По запросу: *{message.text}*", parse_mode="Markdown")
    except Exception:
        await message.answer("❌ Ошибка генерации.")

@dp.message(F.text == "🎨 Нарисовать вас")
@dp.callback_query(F.data == "btn_draw_me")
async def draw_me_start(event, state: FSMContext):
    await state.set_state(Form.draw_portrait)
    msg = "🎨 **Нарисовать ваш Аватар**\n\nОпишите себя:"
    if isinstance(event, types.CallbackQuery):
        await event.message.edit_text(msg, parse_mode="Markdown")
        await event.answer()
    else:
        await event.answer(msg, parse_mode="Markdown")

@dp.message(Form.draw_portrait)
async def process_portrait_generation(message: types.Message, state: FSMContext):
    await state.clear()
    await message.answer("🎨 **Рисую ваш portrait...**")
    try:
        prompt = f"portrait avatar, {message.text}"
        encoded_prompt = urllib.parse.quote(prompt)
        img_url = f"https://image.pollinations.ai/prompt/{encoded_prompt}?width=800&height=800&nologo=true"
        await message.answer_photo(photo=URLInputFile(img_url), caption="🎨 **Ваш персональный Аватар готов!**")
    except Exception:
        await message.answer("❌ Ошибка генерации.")

@dp.message(F.text == "🎲 Рандомайзер")
@dp.callback_query(F.data == "btn_randomizer")
async def randomizer_menu(event, state: FSMContext):
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔢 Число от 1 до 100", callback_data="rand_1_100")],
        [InlineKeyboardButton(text="🪙 Монетка", callback_data="rand_coin")],
        [InlineKeyboardButton(text="⬅️ Назад", callback_data="btn_menu")]
    ])
    msg = "🎲 **Рандомайзер**"
    if isinstance(event, types.CallbackQuery):
        await event.message.edit_text(msg, parse_mode="Markdown", reply_markup=kb)
        await event.answer()
    else:
        await event.answer(msg, parse_mode="Markdown", reply_markup=kb)

@dp.callback_query(F.data == "rand_1_100")
async def rand_number(callback: types.CallbackQuery):
    await callback.message.edit_text(f"🎲 **Число:** `{random.randint(1, 100)}`", parse_mode="Markdown", reply_markup=get_inline_keyboard())

@dp.callback_query(F.data == "rand_coin")
async def rand_coin(callback: types.CallbackQuery):
    await callback.message.edit_text(f"🪙 **Результат:** {random.choice(['Орёл!', 'Решка!'])}", parse_mode="Markdown", reply_markup=get_inline_keyboard())

@dp.message(F.text == "🎭 Сменить характер ИИ")
@dp.callback_query(F.data == "btn_ai_personality")
async def ai_personality_menu(event):
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🟢 Обычный", callback_data="set_p_normal")],
        [InlineKeyboardButton(text="🔥 Дерзкий", callback_data="set_p_toxic")],
        [InlineKeyboardButton(text="⬅ Назад", callback_data="btn_menu")]
    ])
    msg = "🎭 **Выбери характер:**"
    if isinstance(event, types.CallbackQuery):
        await event.message.edit_text(msg, parse_mode="Markdown", reply_markup=kb)
        await event.answer()
    else:
        await event.answer(msg, parse_mode="Markdown", reply_markup=kb)

@dp.callback_query(F.data.startswith("set_p_"))
async def set_personality(callback: types.CallbackQuery):
    p_type = callback.data.replace("set_p_", "")
    USER_AI_PERSONALITY[callback.from_user.id] = p_type
    await callback.message.edit_text(f"✅ **Характер изменён на:** `{p_type}`", parse_mode="Markdown", reply_markup=get_inline_keyboard())

@dp.message(F.text == "👤 Профиль")
async def user_profile(message: types.Message):
    await message.answer(f"👤 **Профиль:**\n🆔 ID: `{message.from_user.id}`", parse_mode="Markdown")

@dp.message(Command("save"))
@dp.callback_query(F.data == "cmd_save_inline")
async def cmd_save(event):
    user_id = event.from_user.id
    chat_id = event.message.chat.id if isinstance(event, types.CallbackQuery) else event.chat.id
    if user_id in ACTIVE_GAMES:
        g = ACTIVE_GAMES[user_id]
        SAVED_GAMES.setdefault(user_id, {})[g["game"]] = g.copy()
        msg = "💾 **Сохранено!**"
    else:
        msg = "ℹ️ Нет игры для сохранения."
    if isinstance(event, types.CallbackQuery):
        await event.answer("Сохранено!")
        await bot.send_message(chat_id=chat_id, text=msg)
    else:
        await event.answer(msg)

@dp.message(Command("load"))
@dp.message(F.text == "📂 Сохранения (/load)")
@dp.callback_query(F.data == "cmd_load_inline")
async def cmd_load(event):
    user_id = event.from_user.id
    chat_id = event.message.chat.id if isinstance(event, types.CallbackQuery) else event.chat.id
    if user_id in SAVED_GAMES and SAVED_GAMES[user_id]:
        msg, reply_m = "📂 **Сохранённые игры:**", get_saved_games_keyboard(user_id)
    else:
        msg, reply_m = "📂 У вас нет сохранений.", get_bot_games_keyboard()
    if isinstance(event, types.CallbackQuery):
        await event.answer()
        await bot.send_message(chat_id=chat_id, text=msg, reply_markup=reply_m)
    else:
        await event.answer(msg, reply_markup=reply_m)

@dp.callback_query(F.data.startswith("load_game_"))
async def load_specific_game(callback: types.CallbackQuery):
    user_id, game_code = callback.from_user.id, callback.data.replace("load_game_", "")
    if user_id in SAVED_GAMES and game_code in SAVED_GAMES[user_id]:
        ACTIVE_GAMES[user_id] = SAVED_GAMES[user_id][game_code].copy()
        await callback.message.edit_text(f"📂 **Загружено!**", parse_mode="Markdown", reply_markup=get_game_action_keyboard(game_code))
    else:
        await callback.answer("Не найдено.", show_alert=True)

@dp.message(Command("stop"))
@dp.callback_query(F.data == "cmd_stop_inline")
async def cmd_stop(event):
    ACTIVE_GAMES.pop(event.from_user.id, None)
    chat_id = event.message.chat.id if isinstance(event, types.CallbackQuery) else event.chat.id
    if isinstance(event, types.CallbackQuery):
        await event.answer()
        await bot.send_message(chat_id=chat_id, text="🛑 **Остановлено.**", reply_markup=get_bot_games_keyboard())
    else:
        await event.answer("🛑 **Остановлено.**", reply_markup=get_bot_games_keyboard())

async def main():
    print("Бот запущен...")
    await bot.delete_webhook(drop_pending_updates=True)
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
